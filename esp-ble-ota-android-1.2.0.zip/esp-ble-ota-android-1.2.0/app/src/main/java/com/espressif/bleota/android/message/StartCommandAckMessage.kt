package com.espressif.bleota.android.message

class StartCommandAckMessage(
        status: Int,
) : CommandAckMessage(status) {
}