# ESP BLE OTA Android
Put the bin file into PhoneStorage: Android/data/com.espressif.bleota.android/files/BLE-OTA/
