package com.espressif.bleota.android.message

class EndCommandAckMessage(
        status: Int,
) : CommandAckMessage(status) {
}