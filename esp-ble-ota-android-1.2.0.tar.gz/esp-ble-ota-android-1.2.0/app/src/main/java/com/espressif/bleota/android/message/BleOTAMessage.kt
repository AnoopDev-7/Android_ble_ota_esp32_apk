package com.espressif.bleota.android.message

abstract class BleOTAMessage {
}