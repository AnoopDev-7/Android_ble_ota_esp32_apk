package com.espressif.bleota.android

class BleOTAConstants {
    companion object {
        const val KEY_BIN_URI = "bin_uri"
        const val KEY_SCAN_RESULT = "scan_result"
    }
}