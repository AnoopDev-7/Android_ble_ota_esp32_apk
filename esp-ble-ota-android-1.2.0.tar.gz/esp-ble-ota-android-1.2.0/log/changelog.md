# Change Log

## 1.1.0
- Update targetSdk to 34
- Update dependencies
- Support using system file picker to select bin file